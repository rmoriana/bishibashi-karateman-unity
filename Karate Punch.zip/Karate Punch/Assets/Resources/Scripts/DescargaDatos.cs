﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DescargaDatos : MonoBehaviour {

	//Muestra las puntuaciones cuando se accede desde el menú principal.
	void Start () {
		this.GetComponent<CargaPuntuaciones> ().descargaPuntuaciones ();
	}

}
