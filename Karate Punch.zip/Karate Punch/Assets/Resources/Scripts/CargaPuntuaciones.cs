﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using UnityEngine;
using UnityEngine.UI;

public class CargaPuntuaciones : MonoBehaviour {

    List<Puntuaciones> puntuacionesList;
    Puntuaciones flag;

    //Descarga las puntuaciones actuales en una lista. Añade la nueva a la lista, elimina el fichero antiguo y crea uno nuevo con las puntuaciones actualizadas.
    public void nuevaPuntuacion(string nombre, int puntos)
    {
        BinaryFormatter bf = new BinaryFormatter();
        puntuacionesList = new List<Puntuaciones>();
        
		if (File.Exists(Application.dataPath +"/Puntuaciones.gd"))
        {         

            //abrimos el fichero
			FileStream file = File.Open(Application.dataPath +"/Puntuaciones.gd", FileMode.Open, FileAccess.Read);
            //deserializamos y lo almacenamos en nuestra lista
            puntuacionesList = (List<Puntuaciones>)bf.Deserialize(file);

            flag = new Puntuaciones();
            flag.nombre = nombre;
            flag.puntos = puntos;
            puntuacionesList.Add(flag);
            file.Close();

            File.Delete(Application.dataPath + "/Puntuaciones.gd");

            FileStream file2 = File.Create(Application.dataPath + "/Puntuaciones.gd");
            //serializamos nuestra List y la guardamos en el fichero   
            bf.Serialize(file2, puntuacionesList);
			             
            file.Close();
        }
        else
        {
			FileStream file = File.Create(Application.dataPath +"/Puntuaciones.gd");
            flag = new Puntuaciones();
            flag.nombre = nombre;
            flag.puntos = puntos;
            puntuacionesList.Add(flag);
            bf.Serialize(file, puntuacionesList);
            file.Close();
        }
    }

    //Descarga las puntuaciones y las muestra ordenadas por puntuación.
    public void descargaPuntuaciones()
    {
		if (File.Exists(Application.dataPath +"/Puntuaciones.gd"))
        {
            puntuacionesList = new List<Puntuaciones>();
            //creamos un binaryFormatter para deserializar
            BinaryFormatter bf = new BinaryFormatter();
            //abrimos el fichero
			FileStream file = File.Open(Application.dataPath +"/Puntuaciones.gd", FileMode.Open, FileAccess.Read);
            //deserializamos y lo almacenamos en nuestra lista
            puntuacionesList = (List<Puntuaciones>)bf.Deserialize(file);
            //Super linea de codigo para ordenar una lista
            List<Puntuaciones> listaOrdenada = puntuacionesList.OrderByDescending(o => o.puntos).ToList();

            for (int i = 0; i < listaOrdenada.Count; i++)
            {
                if(i > 10) //Solo muestra las 10 primeras puntuaciones
                {
                    break;
                }
				GameObject.Find ("ListaPuntuacionesTxt").GetComponent<Text> ().text += listaOrdenada [i].nombre + ": " + listaOrdenada [i].puntos+"\n";
            }
                    
            file.Close();
        }
    }


}
