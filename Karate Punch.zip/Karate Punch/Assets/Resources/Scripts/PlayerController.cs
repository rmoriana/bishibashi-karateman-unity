﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    public GameObject zonaGolpeo;
    public Sprite[] texturaWay;
    public bool golpeando, aturdido, partidaFinalizada;
    public int posSprite, posGolpeo;
  
    void Start () {
        zonaGolpeo = GameObject.FindGameObjectWithTag("ZonaGolpeo");
        zonaGolpeo.SetActive(false);
        texturaWay = Resources.LoadAll<Sprite>("Prefabs/karateSprite");
        //Movimiento estático del personaje
        Invoke("movEstatico", 0.5f);
        //Posicion iniciar de la caja de colision
    }
	
	//Gestion de inputs.
	void Update () {

		if(golpeando == false && aturdido == false && partidaFinalizada == false)
        {
            if (Input.GetKeyDown(KeyCode.A))
            {
                golpeando = true;
                zonaGolpeo.SetActive(true);
                posGolpeo = 0;
                Invoke("golpeCooldown", 0.2f);
                posSprite = 17;
                this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite]; //Pos 2,17
            }
            if (Input.GetKeyDown(KeyCode.S))
            {
                golpeando = true;
                zonaGolpeo.SetActive(true);
                posGolpeo = 1;
                Invoke("golpeCooldown", 0.2f);
                posSprite = 16;
                this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite]; //Pos 16
            }
            if (Input.GetKeyDown(KeyCode.D))
            {
                golpeando = true;
                zonaGolpeo.SetActive(true);
                posGolpeo = 2;
                Invoke("golpeCooldown", 0.2f);
                posSprite = 18;
                this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite]; //Pos 18
            }
        }              
	}

    //Animacion idle.
    void movEstatico()
    {
        if(golpeando == false && aturdido == false)
        {
            if (posSprite == 0)
            {
                posSprite = 8;
                this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite];
            }
            else
            {
                posSprite = 0;
                this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite];
            }
            CancelInvoke("movEstatico");
            Invoke("movEstatico", 0.5f);
        }                      
    }

    //Cuando un enemigo golpea al jugador este queda aturdido.
    public void PlayerAturdido()
    {
        if(aturdido == false) //Para que no le aturdan varios enemigos de forma consecutiva
        {
            aturdido = true;
            Invoke("aturdidoCooldown", 0.7f);
            CancelInvoke("movEstatico");
            posSprite = 4;
            this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite];
            InvokeRepeating("AnimacionAturdido",0, 0.3f);
        }        
    }

    //Elimina el efecto de aturdimiento.
    void aturdidoCooldown()
    {
        aturdido = false;
        CancelInvoke("AnimacionAturdido");
        movEstatico();
    }

    //Animación aturdido.
    void AnimacionAturdido()
    {
        if(posSprite == 4)
        {
            posSprite = 12;            
        }
        else
        {
            posSprite = 4;            
        }
        this.GetComponent<SpriteRenderer>().sprite = texturaWay[posSprite];
    }

    //Termina el cooldown tras golpear.
    void golpeCooldown()
    {
        golpeando = false;
        zonaGolpeo.SetActive(false);
        CancelInvoke("movEstatico");
        movEstatico();
    }
}
