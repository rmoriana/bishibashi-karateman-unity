﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

//Gestiona los cambios de escena y las acciones de los botones.
public class ButtonControl : MonoBehaviour {	

    public void subirPuntuacion()
    {
        string nombre = GameObject.FindGameObjectWithTag("InsertaNombre").GetComponent<InputField>().text;
        int puntos = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().puntuacion;

        if(nombre == "")
        {
            nombre = "Asno";
        }

        GameObject.FindGameObjectWithTag("MainCamera").GetComponent<CargaPuntuaciones>().nuevaPuntuacion(nombre,puntos);

        SceneManager.LoadScene("finalJuego");
    }

    public void volverMenu()
    {
        SceneManager.LoadScene("menuPrincipal");
    }

    public void empezarPartida()
    {
        SceneManager.LoadScene("partida");
    }

    public void verPuntuacioes()
    {
        SceneManager.LoadScene("finalJuego");
    }
}
