﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SceneController : MonoBehaviour {

    public int rachaEnemigos = 0;
    public int puntuacion;
    int layerNumber = 0;
    float tiempoRestante = 60.0f;
    GameObject input, btnOk, btnCancel;

    //Link de algunos botones e inicialización de la partida.
    void Start () {

        Invoke("finalPartida", 60);

        puntuacion = 0;
        input = GameObject.FindGameObjectWithTag("InsertaNombre");
        btnOk = GameObject.FindGameObjectWithTag("CambiaEscena");
        btnCancel = GameObject.FindGameObjectWithTag("Cancelar");

        input.SetActive(false);
        btnOk.SetActive(false);
        btnCancel.SetActive(false);

        enemySpawner();
    }
	
	//Actualiza el tiempo y la puntuación en el canvas.
	void Update () {

        GameObject.FindGameObjectWithTag("Tiempo").GetComponent<Text>().text = ""+tiempoRestante.ToString("f1");
        GameObject.FindGameObjectWithTag("Puntuacion").GetComponent<Text>().text = puntuacion.ToString();
        if(tiempoRestante > 0)
        {
            tiempoRestante -= Time.deltaTime;
        }
        else
        {
            tiempoRestante = 0;
        }
        
    }

    //Secuencia de enemigos que aparecen en el nivel.
    private void enemySpawner()
    {
       // InvokeRepeating("restaTiempo", 0, 0.1f);
        //Oleada 1
        Invoke("generaEnemy", 1);
        Invoke("generaEnemy", 2.5f);
        Invoke("generaEnemy", 3.5f);
        //Oleada 2
        Invoke("generaEnemy", 5.5f);
        Invoke("generaEnemy", 6.5f);
        Invoke("generaEnemy", 7.5f);
        Invoke("generaEnemy", 8);
        //Oleada 3
        Invoke("generaEnemy", 10f);
        Invoke("generaEnemy", 10.5f);
        Invoke("generaEnemy", 11f);
        Invoke("generaEnemy", 11.5f);
        //Oleada 4
        Invoke("generaEnemy", 13.5f);
        Invoke("generaEnemy", 14.5f);
        Invoke("generaEnemy", 15.5f);
        Invoke("generaEnemy", 16.5f);
        Invoke("generaEnemy", 17.5f);
        Invoke("generaEnemy", 18.5f);
        Invoke("generaEnemy", 19.5f);
        Invoke("generaEnemy", 20.5f);
        //Oleada 5
        Invoke("generaEnemy", 22.5f);
        Invoke("generaEnemy", 23);
        Invoke("generaEnemy", 24);
        Invoke("generaEnemy", 24.5f);
        Invoke("generaEnemy", 25.5f);
        Invoke("generaEnemy", 26);
        Invoke("generaEnemy", 26.5f);
        Invoke("generaEnemy", 27);
        //Oleada 6
        Invoke("generaEnemy", 28.5f);
        Invoke("generaEnemy", 29);
        Invoke("generaEnemy", 29.5f);
        Invoke("generaEnemy", 30);
        Invoke("generaEnemy", 30.5f);
        Invoke("generaEnemy", 31);
        Invoke("generaEnemy", 31.5f);
        Invoke("generaEnemy", 32);
        Invoke("generaEnemy", 32.5f);
        //Oleada 7
        Invoke("generaEnemy", 34);
        Invoke("generaEnemy", 34.3f);
        Invoke("generaEnemy", 34.6f);
        Invoke("generaEnemy", 34.9f);
        Invoke("generaEnemy", 35.5f);
        Invoke("generaEnemy", 35.8f);
        Invoke("generaEnemy", 36.1f);
        Invoke("generaEnemy", 36.7f);
        Invoke("generaEnemy", 37);
        Invoke("generaEnemy", 37.3f);
        Invoke("generaEnemy", 37.6f);
        Invoke("generaEnemy", 37.9f);
        //Oleada 8
        Invoke("generaEnemy", 40);
        Invoke("generaEnemy", 40.5f);
        Invoke("generaEnemy", 41);
        Invoke("generaEnemy", 41.5f);
        Invoke("generaEnemy", 42);
        Invoke("generaEnemy", 42.4f);
        Invoke("generaEnemy", 42.9f);
        Invoke("generaEnemy", 43.2f);
        Invoke("generaEnemy", 43.5f);
        Invoke("generaEnemy", 44);
        Invoke("generaEnemy", 44.8f);
        Invoke("generaEnemy", 45.2f);
        //Oleada 9
        Invoke("generaEnemy", 46.7f);
        Invoke("generaEnemy", 47.7f);
        Invoke("generaEnemy", 48.7f);
        Invoke("generaEnemy", 49);
        Invoke("generaEnemy", 49.3f);
        Invoke("generaEnemy", 49.6f);
        Invoke("generaEnemy", 49.9f);
        Invoke("generaEnemy", 50.2f);
        Invoke("generaEnemy", 50.7f);
        Invoke("generaEnemy", 51.2f);
        Invoke("generaEnemy", 52.7f);
        Invoke("generaEnemy", 53);
        //Oleada 10
        Invoke("generaEnemy", 54);
        Invoke("generaEnemy", 54.4f);
        Invoke("generaEnemy", 54.8f);
        Invoke("generaEnemy", 55.1f);
        Invoke("generaEnemy", 55.4f);
        Invoke("generaEnemy", 55.7f);
        Invoke("generaEnemy", 56);
        Invoke("generaEnemy", 56.5f);
        Invoke("generaEnemy", 57);
        Invoke("generaEnemy", 57.3f);
        Invoke("generaEnemy", 57.6f);
        Invoke("generaEnemy", 58);
        Invoke("generaEnemy", 58.3f);
        Invoke("generaEnemy", 58.6f);
        Invoke("generaEnemy", 58.9f);
    }

    //Genera un enemigo por un carril aleatorio.
    void generaEnemy()
    {
        GameObject enemy;
        int randomPos = Random.Range(0, 3);
        layerNumber++;
        switch (randomPos)
        {
            case 0: //por el centro
                int randomSprite = Random.Range(0, 1);
                if(randomSprite == 1)
                {
                    enemy = Instantiate(Resources.Load("Prefabs/EnemyLeft"), new Vector2(0, -7), new Quaternion(0, 0, 0, 0)) as GameObject;
                    enemy.GetComponent<SpriteRenderer>().sortingOrder = layerNumber;
                    enemy.GetComponent<EnemyController>().enemyType = 0;
                    enemy.GetComponent<EnemyController>().enemyPos = 1;
                }
                else
                {
                    enemy = Instantiate(Resources.Load("Prefabs/EnemyRight"), new Vector2(0, -7), new Quaternion(0, 0, 0, 0)) as GameObject;
                    enemy.GetComponent<SpriteRenderer>().sortingOrder = layerNumber;
                    enemy.GetComponent<EnemyController>().enemyType = 1;
                    enemy.GetComponent<EnemyController>().enemyPos = 1;
                }                
                break;
            case 1: //Por la izquierda
                enemy = Instantiate(Resources.Load("Prefabs/EnemyLeft"), new Vector2(-1f, -7), new Quaternion(0, 0, 0, 0)) as GameObject;
                enemy.GetComponent<SpriteRenderer>().sortingOrder = layerNumber;
                enemy.GetComponent<EnemyController>().enemyType = 0;
                enemy.GetComponent<EnemyController>().enemyPos = 0;
                break;
            case 2: //Por la derecha
                enemy = Instantiate(Resources.Load("Prefabs/EnemyRight"), new Vector2(1f, -7), new Quaternion(0, 0, 0, 0)) as GameObject;
                enemy.GetComponent<SpriteRenderer>().sortingOrder = layerNumber;
                enemy.GetComponent<EnemyController>().enemyType = 1;
                enemy.GetComponent<EnemyController>().enemyPos = 2;
                break;
        }
    }    

    //Controla la racha de enemigos para gestionar los combos.
    public void controlaRacha()
    {
        CancelInvoke("reiniciaRacha");
        rachaEnemigos++;
        puntuacion += (rachaEnemigos / 4) + 1;
        Invoke("reiniciaRacha", 1);        
    }

    //Reinicia el combo.
    public void reiniciaRacha()
    {
        rachaEnemigos = 0;
    }

    //Cancela la generación de enemigos y muestra el canvas para introducir la puntuación.
    void finalPartida()
    {
        GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerController>().partidaFinalizada = true;
		CancelInvoke("generaEnemy");
        btnOk.SetActive(true);
        btnCancel.SetActive(true);
        input.SetActive(true);
    }
}
