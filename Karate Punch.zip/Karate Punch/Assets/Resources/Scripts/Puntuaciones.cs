﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Clase serializable para guardar los datos de la partida.
[System.Serializable]
public class Puntuaciones{

    public string nombre { get; set; }
    public int puntos { get; set; }
}
