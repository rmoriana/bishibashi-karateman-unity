﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour {

   
    public int enemyType; //Se asigna al crear el enemigo en SceneController. Si es un 1 tiene el cuchillo en la derecha y si es un 0 en la izquierda
    public int enemyPos; //Carril por el que va el enemigo para controlar las colisiones. 0 - Izquierda / 1 - Central / 2 - Derecha
    public int numTextura;
    bool colision; //Flag para que el enemigo no se mueva si ha sido golpeado o ha llegado al jugador
    public Sprite[] texturaEnemy;
   
    //Cada enemigo carga las texturas (muy poco óptimo).
    void Start () {

        texturaEnemy = Resources.LoadAll<Sprite>("Prefabs/karateSprite");
        InvokeRepeating("GestionMovimiento", 0, 0.2f);
        if(enemyType == 0)
        {
            numTextura = 6;
        }
        else
        {
            numTextura = 5;
        }        
    }
	
	//Si no colisiona con algo, sigue avanzando.
	void Update () {
        if(colision == false)
        {
            transform.position = new Vector2(transform.position.x, transform.position.y + 0.1f);
        }        
    }

    //Animaciones de movimiento.
    void GestionMovimiento()
    {
        if (enemyType == 0) //Izquierda 6,14,21
        {
            if(numTextura == 6)
            {
                numTextura = 14;                
            }
            else if(numTextura == 14)
            {
                numTextura = 20;
            }
            else
            {
                numTextura = 6;
            }
            this.GetComponent<SpriteRenderer>().sprite = texturaEnemy[numTextura];
        }
        else //Derecha 5,13,19
        {
            if (numTextura == 5)
            {
                numTextura = 13;
            }
            else if(numTextura == 13)
            {
                numTextura = 19;
            }
            else
            {
                numTextura = 5;
            }
            this.GetComponent<SpriteRenderer>().sprite = texturaEnemy[numTextura];
            
        }
    }

    //Gestion de las colisiones. O golpea al jugador o es golpeado por el jugador.
    void OnTriggerEnter2D(Collider2D other)
    {         
        if(other.gameObject.tag == "Player")
        {
            colision = true; //El enemigo deja de moverse
            CancelInvoke("GestionMovimiento");
            other.gameObject.GetComponent<PlayerController>().PlayerAturdido(); //Aturde al jugador
            GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().reiniciaRacha();
            Invoke("Autodestruccion", 0.4f);

        } else if(other.gameObject.tag == "ZonaGolpeo")
        {            
            GameObject hero = GameObject.FindGameObjectWithTag("Player");
            if (hero.GetComponent<PlayerController>().posGolpeo == enemyPos) //Si el heroe esta golpeando en la posicion del enemigo
            {
                //SUMA PUNTOS
                GameObject.FindGameObjectWithTag("MainCamera").GetComponent<SceneController>().controlaRacha();                

                //Cambia el sprite dependiendo del carril 22,15,24
                colision = true; //El enemigo deja de moverse
                CancelInvoke("GestionMovimiento");
                switch (enemyPos)
                {
                    case 0: this.GetComponent<SpriteRenderer>().sprite = texturaEnemy[22]; break;
                    case 1: this.GetComponent<SpriteRenderer>().sprite = texturaEnemy[15]; break;
                    case 2: this.GetComponent<SpriteRenderer>().sprite = texturaEnemy[24]; break;
                }
                this.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, -75));
                Invoke("Autodestruccion", 0.4f);
            }
        }
    }

    //Se autodestruye.
    void Autodestruccion()
    {
        Destroy(this.gameObject);
    }
}
